<?php
  require_once 'sql_login.php';
  session_start();
  $conn = new mysqli($hn,$un,$pw,$db);
  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true)
    $is_signed_in=false;
  else
    $is_signed_in=true;
  $id=$_POST["product"];
  $query="SELECT * from movies where id=".$id;
  $result=$conn->query($query);
  if(!$result)
    die("Database access failed.");
  $row=mysqli_fetch_assoc($result);
  $name=$row["movie_name"];
  $genre=$row["genre"];
  $desc=$row["descrip"];
  $dir=$row["img_directory"];
  $cast=$row["cast"];
  $price=$row["price"];
  
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ORACLE</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
    <!-- CSS -->
    <link href="style_product.css" rel="stylesheet">
    <link href="stylesheet_product.css" rel="stylesheet">
    <meta name="robots" content="noindex,follow" />

    <script>

      function sub()
      {
        document.getElementById("myForm").submit();
      }

    </script>


  </head>

  <body>
     <form action="search.php" method="post"> 
     <div id="logo"> <!-- <img src="logoImage.png" alt="sample logo">  -->
      <!-- Company Logo text --> 
      Chillflix </div>
      <div id="headerLinks">
        
      <input type="text" name="search" id="search" placeholder="search" class="topSearch"><a href = "#"><input type="submit" name="button" value="search" class="searchButton"></a>
    </form>
<?php
        if($is_signed_in)
        {
          echo "<a>Hello, ".$_SESSION["username"]."</a>";
          echo <<<_END
         <a href="cart.php" title="Cart">Cart</a>  
         <a href="signout.php" title="signout">Sign Out</a></div>         
_END;
        }
        else
        {
          echo <<<_END
          <a href="signin.php" title="Login">Login</a><a href="signup.php" title="Sign Up">Sign Up</a></div>
_END;
        }

      ?>
  </header>
    <main class="container">

      <!-- Left Column / Headphones Image -->
      <div class="left-column">
       <!--  <img data-image="black" src="images/black.png" alt="">
        <img data-image="blue" src="images/blue.png" alt=""> -->
        <img class="active" src=<?php echo "\"".$dir."\""?>>
      </div>


      <!-- Right Column -->
      <div class="right-column">

        <!-- Product Description -->
        <div class="product-description">
          <span><?php echo $genre;?></span>
          <h1><?php echo $name;?></h1>
          <p><?php echo $desc;?></p>
          <p><?php echo $cast;?></p>
        </div>

        <!-- Product Configuration -->
       <!--  -->
        <!-- Product Pricing -->
        <div class="product-price">
          <span>$<?php echo $price;?></span>
          <form action="process1.php" method="post" id="myForm">
            <input type="hidden" name="cart" value=<?php echo "\"".$id."\"";?>>
          <a class="cart-btn" href='#' onclick="sub()"> Add to cart </a>
        </form>
        </div>
      </div>
    </main>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js" charset="utf-8"></script>
    <script src="script.js" charset="utf-8"></script>
  </body>
</html>
