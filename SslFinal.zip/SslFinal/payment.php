<?php

session_start();
$_SESSION["cart"]="";
require_once "sql_login.php";

$link=mysqli_connect($hn,$un,$pw,$db);

if (mysqli_connect_errno())
{
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}

$movie_ids=explode(",", $_POST["movies"]);
$movie_names=array();
$movie_prices=array();
foreach($movie_ids as $id)
{
  $query="SELECT *  from movies WHERE id=$id";
  $result=mysqli_query($link,$query); 
  if (!$result) {
        die('<p>query failed: <p>' . mysqli_error());
  }
  $row=mysqli_fetch_assoc($result);
  array_push($movie_names,$row["movie_name"]);
  array_push($movie_prices,$row["price"]);
  $price_total=0;
  foreach($movie_prices as $price)
  {
    $price_total += $price;
  }

}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Payment</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link rel="stylesheet" href="payment.css">
</head>
<body>
  <main class="page payment-page">
    <section class="payment-form dark">
      <div class="container">
        <div class="block-heading">
          <h2>Payment</h2>
          <!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in, mattis vitae leo.</p> -->
        </div>
        <form action="redirect.php" method="post">
          <div class="products">
            <h3 class="title">Checkout</h3>
            
            <!--
            <div class="item">
              <span class="price">$200</span>
              <p class="item-name">Product 1</p>
              <p class="item-description">Product 1</p>
            </div>
             -->
            <?php
            echo "<input type=\"hidden\" name=\"movies\" value=\"".$_POST["movies"]."\">";
            for($i=0;$i<sizeof($movie_names);$i++)
            {
              echo <<<_END
              <div class="item">
              <span class="price">$movie_prices[$i]</span>
              <p class="item-name">$movie_names[$i]</p>
            </div>
_END;
            }


            ?>
            
            <div class="total">Total<span class="price"><?php echo $price_total;?></span></div>
          </div>
          <div class="card-details">
            <h3 class="title">Credit Card Details / Wallet / UPI</h3>
            <div class="row">
              <div class="form-group col-sm-7">
                <label for="card-holder">Card Holder</label>
                <input id="card-holder" type="text" class="form-control" placeholder="Card Holder" aria-label="Card Holder" aria-describedby="basic-addon1">
              </div>
              <div class="form-group col-sm-5">
                <label for="">Expiration Date</label>
                <div class="input-group expiration-date">
                  <input type="text" class="form-control" placeholder="MM" aria-label="MM" aria-describedby="basic-addon1" maxlength="2" minlength="2">
                  <span class="date-separator">/</span>
                  <input type="text" class="form-control" placeholder="YY" aria-label="YY" aria-describedby="basic-addon1" maxlength="2" minlength="2">
                </div>
              </div>
              <div class="form-group col-sm-8">
                <label for="card-number">Card Number</label>
                <input id="card-number" type="text" class="form-control" placeholder="Enter 16-digit Card Number" aria-label="Card Holder" aria-describedby="basic-addon1"maxlength="16" minlength="16">
              </div>
              <div class="form-group col-sm-4">
                <label for="cvc">CVC</label>
                <input id="cvc" type="password" class="form-control" placeholder="CVC" aria-label="Card Holder" aria-describedby="basic-addon1" minlength="3" maxlength="3">
              </div>
              <div class="form-group col-sm-12">
                <button type="submit" class="btn btn-primary btn-block">Proceed</button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </section>
  </main>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>