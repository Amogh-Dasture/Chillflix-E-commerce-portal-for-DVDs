<?php

session_start();

require_once "sql_login.php";

$link=mysqli_connect($hn,$un,$pw,$db);

if (mysqli_connect_errno())
{
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}
$id=$_SESSION["id"];
$query="SELECT sold_movie_ids from users where id=".$id;
$result=mysqli_query($link,$query); 
if (!$result)
{
    die('<p>query failed: <p>' . mysqli_error($link));
}
$row=mysqli_fetch_row($result);
$sold_movie_ids=explode(',',$row[0]);


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>ORACLE</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link href="./stylesheet.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="./bootstrap_homepage.css">
<!--===============================================================================================-->
</head>
<body>
	<div id="mainWrapper">
  <header> 
    <!-- This is the header content. It contains Logo and links -->
    <div id="logo"> <!-- <img src="logoImage.png" alt="sample logo">  -->
      <!-- Company Logo text --> 
      Chillflix </div>
      <div id="headerLinks">
     <a href = "../add_product"><button name="upload" class = "searchButton">Sell New Movie</button></a>
      <a href = ".."><button name="Back To Home" class = "searchButton">Back To Home</button></a>
      
          <a href="signin.php" title="Login"><?php echo "Hello, ".$_SESSION["username"];?></a><a href="../signout.php" title="Sign Out">Sign Out</a>

  </header>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100 ver1 m-b-110">
					<div class="table100-head">
						<table>
							<thead>
								<tr class="row100 head">
									<th class="cell100 column1">Movie Title</th>
									<th class="cell100 column2">Genre</th>
									<th class="cell100 column3">Price</th>
									<!-- <th class="cell100 column3">        </th> -->
									<!-- <th class="cell100 column4">Update</th> -->
								</tr>
							</thead>
						</table>
					</div>

					<div class="table100-body js-pscroll">
						<table>
							<tbody>
								<!-- <tr class="row100 body">
									<td class="cell100 column1">Bad Boys 2</td>
									<td class="cell100 column2">Action</td>
									<td class="cell100 column3">$35</td>
									<td class="cell100 column3">5</td>
									<td button onclick="#">EDIT</button></td>
								</tr>

								<tr class="row100 body">
									<td class="cell100 column1">Hangover</td>
									<td class="cell100 column2">Comedy</td>
									<td class="cell100 column3">$35</td>
									<td class="cell100 column3">3</td>
									<td button onclick="#">EDIT</button></td>
								</tr> -->
								<form action="edit.php" method="post">
								<?php

								if($row[0]=="")
								{
									echo "<h1> Your history is empty</h1>";
								}
								else{
								foreach($sold_movie_ids as $movie_id)
								{
									//echo $movie_id;
									$query="SELECT movie_name,genre,price from movies where id=".$movie_id;
									$result=mysqli_query($link,$query); 
									if (!$result)
									{
									    die('<p>query failed: <p>' . mysqli_error($link));
									}
									$row1=mysqli_fetch_row($result);
									$movie_name=$row1[0];
									$genre=$row1[1];
									$price=$row1[2];


									echo "<tr class=\"row100 body\">";
									echo <<<_END
									<td class="cell100 column1">$movie_name</td>
									<td class="cell100 column2">$genre</td>
									<td class="cell100 column3">\$$price</td>
							
								</tr>
_END;
								}
							}

								?>



								
							</tbody>
						</table>
					</div>
				</div>

			</div>
		</div>
	</div>


<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function(){
			var ps = new PerfectScrollbar(this);

			$(window).on('resize', function(){
				ps.update();
			})
		});
			
		
	</script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>