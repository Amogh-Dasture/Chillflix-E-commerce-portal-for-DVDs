<?php
  require_once 'sql_login.php';
  session_start();
  $conn = new mysqli($hn,$un,$pw,$db);
  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true)
    $is_signed_in=false;
  else
    $is_signed_in=true;
  
?>
<html>
<head>
<meta charset="utf-8">
<title>ORACLE</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="./stylesheet1.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="./bootstrap_homepage.css">
<link rel="stylesheet" href="product-list-vertical.css">
<link rel="stylesheet" href="http://maxcdn.bootsrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<!--<script>var __adobewebfontsappname__="dreamweaver"</script><script src="http://use.edgefonts.net/montserrat:n4:default;source-sans-pro:n2:default.js" type="text/javascript"></script>-->
</head>

<body>

<div id="mainWrapper">
  <header> 
    <form action="search.php" method="post">
    <!-- This is the header content. It contains Logo and links -->
    <div id="logo"> <!-- <img src="logoImage.png" alt="sample logo">  -->
      <!-- Company Logo text --> 
      Chillflix </div>
      <div id="headerLinks">
      <input type="text"  name="search" id="search" placeholder="search" class = "topSearch"><a><input type="submit" name="button" value="search" class="searchButton"></a>
      </form>
      <?php
        if($is_signed_in)
        {
          echo "<a>Hello, ".$_SESSION["username"]."</a>";
          echo <<<_END
         <a href="cart.php" title="Cart">Cart</a></div>           
_END;
        }
        else
        {
          echo <<<_END
          <a href="login.php" title="Login">Login</a><a href="signup.php" title="Sign Up">Sign Up</a></div>
_END;
        }
      ?>
  
  </header>

  <div id="content">
    <section class="sidebar"> 
      <!-- This adds a sidebar with 1 searchbox,2 menusets, each with 4 links -->
      
      <div id="menubar">
        <nav class="menu">
          <center><h2><!-- Title for menuset 1 -->Genres</h2></center>
          <hr>
          <ul>
            <!-- List of links under menuset 1 -->
            <li><a href="action.php" title="Link">Action</a></li>
            <li><a href="scifi.php" title="Link">Sci-Fi</a></li>
            <li><a href="romance.php" title="Link">Romance</a></li>
            <li><a href="comedy.php" title="Link">Comedy</a></li>
            <li><a href="drama.php" title="Link">Drama</a></li>
            <li><a href="animated.php" title="Link">Animated</a></li>
            <!-- <li class="notimp">\notimp class is applied to remove this link from the tablet and phone views<a href="#"  title="Link">Link 4</a></li> -->
          </ul>
        </nav>
        <!-- <nav class="menu"> -->
          <!-- <h2>MENU ITEM 2 </h2> -->
          <!-- \Title for menuset 2 -->
          <!-- <hr> -->
          <!-- <ul> -->
            <!--\List of links under menuset 2 -->
            <!-- <li><a href="#" title="Link">Link 1</a></li> -->
            <!-- <li><a href="#" title="Link">Link 2</a></li> -->
            <!-- <li><a href="#" title="Link">Link 3</a></li> -->
            <!-- <li class="notimp">\notimp class is applied to remove this link from the tablet and phone views<a href="#" title="Link">Link 4</a></li> -->
          <!-- </ul> -->
        <!-- </nav>--> 
      </div>
    </section>



    <?php
        // $str = $_POST["search"];
        // $str=(string)$str;
        // strtolower($str);
        // $query="SELECT movie_name FROM movies";
        // $result=$conn->query($query);
        // $counter=0;
        // $index;
        // $indexes = array();
        // $flag = 1;
        // if(!$result)
        //   die("Database access failed.");
        // $num_r = $result->num_rows;
        // for ($i=1; $i <=$num_r ; $i++) 
        // { 
        //   $str2=$result->fetch_array(MYSQLI_ASSOC);
        //   $str3=$str2["movie_name"];
        //   $str3=strtolower($str3);
        //   if(strpos($str3, $str)!== false)
        //   {
        //     $counter+=1;
        //     array_push($indexes, $i);
        //     $index = $counter;
        //   }
        //   if(count($indexes) == 4)
        //   {
        //     break;
        //   }
        // }
        // $size = count($indexes);
        // if($size<4)
        // {
        //   if($size==0)
        //   {
        //     $flag = 0;
        //   }
        //   else
        //   {
        //     $a = 4-$size;
        //     while($a>0)
        //     {
        //       $index+=1;
        //       array_push($indexes, $index);
        //       $a-=1;
        //     }
        //   }
        // }



    // <!-- <section class="mainContent"> -->
     

//       for($x=1;$x<=3;$x++)
//       {
//         echo '<div class="productRow">' ;
//         if($x==1)
//         {
//           echo <<<_END
//           <h2>RECOMMENDED FOR YOU</h2><br>
// _END;
//         }
//         for($y=1;$y<=3;$y++)
//         {
//           $row=$result->fetch_array(MYSQLI_ASSOC);
//           $img_dir=htmlspecialchars($row["img_directory"]);
//           $price=htmlspecialchars($row["price"]);
//           $name=htmlspecialchars($row["movie_name"]);
//           $rec=htmlspecialchars($row["recommended"]);


//           echo <<<_END
//           <article class="productInfo">
//           <div><a href = '#'><img alt="sample" src="$img_dir"></a></div>
//           <p class="price"> \$$price </p>
//           <p class="productContent"> $name </p>
//           </article>  
// _END;
//         }
//         echo "</div>";
//       } 

        // echo "<ul class=\"product-list-vertical\">";
        $query="SELECT * FROM movies WHERE genre =\"romance\"";
        $result=$conn->query($query);
          if(!$result)
          {
            die();
          }
          $num_r=mysqli_num_rows($result);
        
        for($x=1; $x<=$num_r; $x++)
        {
          // $ind = $indexes[$x-1];
          $row=$result->fetch_array(MYSQLI_ASSOC);
          $img_dir=htmlspecialchars($row["img_directory"]);
          $price=htmlspecialchars($row["price"]);
          $name=htmlspecialchars($row["movie_name"]);
          $desc=htmlspecialchars($row["descrip"]);
          $ind=htmlspecialchars($row["id"]);
          echo "<center>";
          echo "<ul class=\"product-list-vertical\">";

          echo <<<_END
          <li>
          <script>
          function sub$x()
          {
            document.getElementById("myForm$ind").submit();
          }
          </script>
          <form action="product.php" id="myForm$ind" method="post">
          <input type="hidden" name="product" value="$ind">
          </form>
          <a href="#" onclick="sub$x()" class="product-photo">
                <img src="$img_dir" height="160" alt="$name" />
            </a>
            <div class="product-details">
                <h2><a href="#" onclick="sub$x()">$name</a></h2>

                <p class="product-description">$desc</p>

                <p class="product-price">\$$price</p>
            </div>

          </li>

_END;
        echo " </ul>";
        echo "</center>";
        }
        
      
     ?>


      
    <!-- </section> -->
  </div>
  <footer> 
    <!-- This is the footer with default 3 divs -->
    <div class="footerlinks">
      <p><a href="#" title="Link">chill@gmail.com </a></p>
      <!-- <p><a href="#" title="Link"></a></p> -->
      <!-- <p><a href="#" title="Link">Link 3</a></p> -->
    </div>
  </footer>
</div>
<script src="./jquery-1.11.3.min.js"></script> 
<script src="./bootstrap.js"></script>
</body>
</html>
