<?php

session_start();

$_SESSION["cart"]="";

echo <<<_END
	<h1> Your cart is now empty. Redirecting to cart... </h1>
	<script> 
	function Redirect() 
    {  
        window.location="cart.php"; 
    } 
    setTimeout('Redirect()', 3000);   
    </script>
_END;