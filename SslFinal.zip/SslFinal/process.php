<?php

session_start();
 if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true)
    $is_signed_in=false;
  else
    $is_signed_in=true;
if(!$is_signed_in)
{
	echo <<<_END
	<h1> Please login to perform this action. Redirecting to the login page... </h1>
	<script> 
	function Redirect() 
    {  
        window.location="signin.php"; 
    } 
    setTimeout('Redirect()', 3000);   
    </script>
_END;
die();
}

require_once "sql_login.php";

$link=mysqli_connect($hn,$un,$pw,$db);

if (mysqli_connect_errno())
{
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}

if(isset($_POST["buy"]))
{
	$query="SELECT id FROM movies WHERE recommended=".$_POST["buy"];
	$result=mysqli_query($link,$query); 
  	if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error());
 	}
 	$row=mysqli_fetch_assoc($result);
 	$movies=$row["id"];
 	echo <<<_END
 	<form id="myForm" action="./payment.php" method="post">
 		<input type="hidden" name="movies" value="$movies">
 	</form>
 	<script>
 		document.getElementById("myForm").submit();
 	</script>
_END;
}

if(isset($_POST["cart"]))
{
	$query="SELECT id FROM movies WHERE recommended=".$_POST["cart"];
	$result=mysqli_query($link,$query); 
  	if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error());
 	}
 	$row=mysqli_fetch_assoc($result);
 	$movies=$row["id"];
  if(!isset($_SESSION["cart"]))
  {
    $_SESSION["cart"]="";
  }
  if($_SESSION["cart"] != "")
  {
    $_SESSION["cart"]=$_SESSION["cart"].',';
  }
 	$_SESSION["cart"]=$_SESSION["cart"].$movies;
 	echo <<<_END
	<h1> The product has been added to cart. Redirecting to the previous page </h1>
	<script> 
	function Redirect() 
    {  
        window.history.back(); 
    } 
    setTimeout('Redirect()', 3000);   
    </script>
_END;
die();


}

?>