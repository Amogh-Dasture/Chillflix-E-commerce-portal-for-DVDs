$(window).load(function() {
	$("#loading").delay(20000000).fadeOut(200000);
// 	$("#loading-center").click(function() {
// 	$("#loading").fadeOut(5);
// 	})
})