<?php
	session_start();
	require_once "sql_login.php";

	$link=mysqli_connect($hn,$un,$pw,$db);
	$id=$_SESSION["id"];
	$query="SELECT purchased_movie_ids FROM users WHERE id=".$id;

	$result=mysqli_query($link,$query); 
  	if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error());
 	}
 	$row=mysqli_fetch_row($result);
 	if($row[0] != "")
 	{
 		$query="update users set purchased_movie_ids = concat(purchased_movie_ids,',') where id=".$id;
 		mysqli_query($link,$query); 
 	}
 	$movies=$_POST["movies"];
 	$query="update users set purchased_movie_ids = concat(purchased_movie_ids,\"$movies\") where id=".$id;
 	mysqli_query($link,$query); 



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="http://simbyone.com/wp-content/uploads/2014/04/3455e6f65c33232a060c28829a49b1cb.png">
<title>Processing...</title>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href="_css/Icomoon/style.css" rel="stylesheet" type="text/css" />
<link href="_css/main.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="_scripts/jquery-2.0.2.min.js"></script>
<script type="text/javascript" src="_scripts/main.js"></script>

<style>
#loading{
	background-color: #f0c600;
	height: 100%;
	width: 100%;
	position: fixed;
	z-index: 1;
	margin-top: 0px;
	top: 0px;
}
#loading-center{
	width: 100%;
	height: 100%;
	position: relative;
	}
#loading-center-absolute {
	position: absolute;
	left: 50%;
	top: 50%;
	height: 150px;
	width: 150px;
	margin-top: -75px;
	margin-left: -75px;
    -moz-border-radius: 50% 50% 50% 50%;
	-webkit-border-radius: 50% 50% 50% 50%;
	border-radius: 50% 50% 50% 50%;

}
.object{
	width: 20px;
	height: 20px;
	background-color: #FFF;
	position: absolute;
	-moz-border-radius: 50% 50% 50% 50%;
	-webkit-border-radius: 50% 50% 50% 50%;
	border-radius: 50% 50% 50% 50%;
	-webkit-animation: animate 0.8s infinite;
	animation: animate 0.8s infinite;
	}


#object_one {
	top: 19px;
	left: 19px;	

	}
#object_two {
	top: 0px;
	left: 65px; 
	-webkit-animation-delay: 0.1s; 
    animation-delay: 0.1s;

	}
#object_three {
	top: 19px;
	left: 111px; 	
	-webkit-animation-delay: 0.2s; 
    animation-delay: 0.2s; 

	}
#object_four {
	top: 65px;
	left: 130px; 
	-webkit-animation-delay: 0.3s; 
    animation-delay: 0.3s; 
}
#object_five {
	top: 111px;
	left: 111px; 
	-webkit-animation-delay: 0.4s; 
    animation-delay: 0.4s; 
}
#object_six {
	top: 130px;
	left: 65px;
	-webkit-animation-delay: 0.5s; 
    animation-delay: 0.5s; 
}
#object_seven {
	top: 111px;
	left: 19px;
	-webkit-animation-delay: 0.6s; 
    animation-delay: 0.6s; 
}
#object_eight {
	top: 65px;
	left: 0px;
	 -webkit-animation-delay: 0.7s; 
    animation-delay: 0.7s; 
}




@-webkit-keyframes animate {
 
  25% {
	-ms-transform: scale(1.5); 
   	-webkit-transform: scale(1.5);   
    transform: scale(1.5);  
	  }


  75% {
	-ms-transform: scale(0); 
   	-webkit-transform: scale(0);  
    transform: scale(0);  
	  }


}

@keyframes animate {
  50% {
	-ms-transform: scale(1.5,1.5); 
   	-webkit-transform: scale(1.5,1.5); 
    transform: scale(1.5,1.5); 
	  }
 
  100% {
	-ms-transform: scale(1,1); 
   	-webkit-transform: scale(1,1); 
    transform: scale(1,1); 
	  }
  
}




</style>
</head>
<body>
<div id="loading">
<div id="loading-center">
<div id="loading-center-absolute">
<div class="object" id="object_one"></div>
<div class="object" id="object_two"></div>
<div class="object" id="object_three"></div>
<div class="object" id="object_four"></div>
<div class="object" id="object_five"></div>
<div class="object" id="object_six"></div>
<div class="object" id="object_seven"></div>
<div class="object" id="object_eight"></div>

</div>
</div>
 
</div>

<script type="text/javascript">   
    function Redirect() 
    {  
        window.location="./thank_you.html"; 
    } 
    setTimeout('Redirect()', 2000);   
</script>

<!--

<div id="header">
<div id="header-left">

<div id="header-left-icon"><a href="http://simbyone.com/30-css-page-preload-animations/"><i class="fa fa-angle-left"></i></a></div>
<div id="header-left-text"><a href="http://simbyone.com/30-css-page-preload-animations/">30 CSS Page Preload Animations</a></div>
</div>

<div id="header-right">
<div id="header-right-icon"><a href="http://simbyone.com/css-page-preload-animations/css-page-preload-animations.zip"><i class="fa fa-cloud-download"></i></a></div>
<div id="header-right-text"><a href="http://simbyone.com/css-page-preload-animations/css-page-preload-animations.zip">Download Source</a></div>
</div>
</div>
-->

<!--
<div id="wrapper">
<div id="wrapper-center">
<div class="wrapper-center-title">Square Animations</div>
<div class="wrapper-center-content">
<a href="demo1.html">Demo 1</a>
<a href="demo2.html">Demo 2</a>
<a href="demo3.html">Demo 3</a>
<a href="demo4.html">Demo 4</a>
<a href="demo5.html">Demo 5</a>
<a href="demo6.html">Demo 6</a>
<a href="demo7.html">Demo 7</a>
<a href="demo8.html">Demo 8</a>
<a href="demo9.html">Demo 9</a>
<a href="demo10.html">Demo 10</a>
</div>
<div class="wrapper-center-title">Round Animations</div>
<div class="wrapper-center-content">
<a href="demo11.html">Demo 11</a>
<a href="demo12.html">Demo 12</a>
<a href="demo13.html">Demo 13</a>
<a href="demo14.html">Demo 14</a>
<a href="demo15.html">Demo 15</a>
<a href="demo16.html">Demo 16</a>
<a href="demo17.html">Demo 17</a>
<a href="demo18.html">Demo 18</a>
<a href="demo19.html">Demo 19</a>
<a href="demo20.html">Demo 20</a>
</div>
<div class="wrapper-center-title">Various Animations</div>
<div class="wrapper-center-content">
<a href="demo21.html">Demo 21</a>
<a href="demo22.html">Demo 22</a>
<a href="demo23.html">Demo 23</a>
<a href="demo24.html">Demo 24</a>
<a href="demo25.html">Demo 25</a>
<a href="demo26.html">Demo 26</a>
<a href="demo27.html">Demo 27</a>
<a href="demo28.html">Demo 28</a>
<a href="demo29.html">Demo 29</a>
<a href="demo30.html">Demo 30</a>
</div>
</div>

-->
<!-- </div> -->



</body>
</html>
