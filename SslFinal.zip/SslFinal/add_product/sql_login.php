<?php // login.php
    $hn = "localhost";
    $un = "root";
    $pw = "drunkenmaster";
    $db ="ssl_project";
?>


