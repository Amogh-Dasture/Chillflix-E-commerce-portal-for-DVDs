<?php

session_start();
require_once "sql_login.php";

$link=mysqli_connect($hn,$un,$pw,$db);
$query="SELECT id from movies";
$result=mysqli_query($link,$query); 
  	if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error());
 	}
 $total_movies=mysqli_num_rows($result);
 $total_movies += 1;

$target_dir = "../movie_images/";
$target_file = $target_dir . $total_movies.".jpg";
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_dir . basename($_FILES["file_cv"]["name"]),PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if($imageFileType != "jpg") 
{
    echo "Sorry, only JPG files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) 
{
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} 
else 
{
    if (move_uploaded_file($_FILES["file_cv"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file_cv"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}


$title=mysqli_real_escape_string($link,$_POST["title"]);
$genre=mysqli_real_escape_string($link,$_POST["genre"]);
$desc=mysqli_real_escape_string($link,$_POST["description"]);
$cast=mysqli_real_escape_string($link,$_POST["cast"]);
$id=mysqli_real_escape_string($link,$_SESSION["id"]);
$price=mysqli_real_escape_string($link,$_POST["price"]);

$query="INSERT INTO movies(
			movie_name,
			img_directory,
			genre,
			dealer_id,
			descrip,
			cast,
			price)
			VALUES(
			'$title',
			\"./movie_images/$total_movies.jpg\",
			'$genre',
			$id,
			'$desc',
			'$cast',
			$price
			)
			";
$result=mysqli_query($link,$query);
if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error($link));
 	}
$query="SELECT sold_movie_ids FROM users WHERE id=".$id;

$result=mysqli_query($link,$query); 
  	if (!$result)
  	{
        die('<p>query failed: <p>' . mysqli_error());
 	}
 	$row=mysqli_fetch_row($result);
 	if($row[0] != "")
 	{
 		$query="update users set sold_movie_ids = concat(sold_movie_ids,',') where id=".$_SESSION["id"];
 		mysqli_query($link,$query); 
 	}
 	$query="update users set sold_movie_ids = concat(sold_movie_ids,\"$total_movies\") where id=".$_SESSION["id"];
 	$result=mysqli_query($link,$query);


header("location: ../selling_history");
?>