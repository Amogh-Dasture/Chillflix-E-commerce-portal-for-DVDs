<?php

session_start();

require_once "sql_login.php";

$link=mysqli_connect($hn,$un,$pw,$db);

if (mysqli_connect_errno())
{
  die("Failed to connect to MySQL: " . mysqli_connect_error());
}

$movie_ids=explode(',',$_SESSION["cart"]);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Shopping Cart</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" href="shopping-cart.css">
</head>
<body>
	<main class="page">
	 	<section class="shopping-cart dark">
	 		<div class="container">
		        <div class="block-heading">
		          <h2>Shopping Cart</h2>
		         <!--  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in, mattis vitae leo.</p> -->
		        </div>
		        <div class="content">
	 				<div class="row">
	 					<div class="col-md-12 col-lg-8">
	 						<div class="items">
				 				<!-- <div class="product">
				 					<div class="row">
					 					<div class="col-md-3">
					 						<img class="img-fluid mx-auto d-block image" src="image.jpg">
					 					</div>
					 					<div class="col-md-8">
					 						<div class="info">
						 						<div class="row">
							 						<div class="col-md-5 product-name">
							 							<div class="product-name">

								 							<div class="product-info">
									 							
									 						</div>
									 					</div>
							 						</div>
							 						<div class="col-md-4 quantity">
							 							<label for="quantity">Quantity:</label>
							 							<input id="quantity" type="number" value ="1" class="form-control quantity-input">
							 						</div>
							 						<div class="col-md-3 price">
							 							<span>$120</span>
							 						</div>
							 					</div>
							 				</div>
					 					</div>
					 				</div>
				 				</div>
				 -->

				 <?php
				// print_r($movie_ids);
				 $total_price=0;
				 if($_SESSION["cart"]=="")
				 {
				 	echo "<h1>Your cart is empty</h1>";
				 }
				 else{
				 foreach($movie_ids as $id)
				 {
				 	$query="SELECT movie_name,img_directory,price from movies where id=".$id;
				 	$result=mysqli_query($link,$query); 
				  if (!$result)
				  {
				    die('<p>query failed: <p>' . mysqli_error($link));
				 	}
				 	$row=mysqli_fetch_assoc($result);
				 	$name=$row["movie_name"];
				 	$dir=$row["img_directory"];
				 	$price=$row["price"];
				 	$total_price+=$price;
				 	echo <<<_END
								<div class="product">
				 					<div class="row">
					 					<div class="col-md-3">
					 						<img class="img-fluid mx-auto d-block image" src="$dir">
					 					</div>
					 					<div class="col-md-8">
					 						<div class="info">
						 						<div class="row">
							 						<div class="col-md-5 product-name">
							 							<div class="product-name">
								 							<a>$name</a>
								 						</div>
							 						</div>
							 						<div class="col-md-4 quantity">
							 							<label for="quantity">Quantity:</label>
							 							<input id="quantity" type="number" value ="1" class="form-control quantity-input">
							 						</div>
							 						<div class="col-md-3 price">
							 							<span>\$$price</span>
							 						</div>
							 					</div>
							 				</div>
					 					</div>
					 				</div>
				 				</div>
_END;


				 }
				}

				 	?>
				 				</div>
				 			</div>
			 			</div>
			 			<script type="text/javascript">
			 				
			 				function redirect1()
			 				{
			 					window.location="remove_all.php";
			 				}
			 				function redirect2()
			 				{
			 					window.location="index.php";
			 				}
			 			</script>
			 			<div class="col-md-12 col-lg-4">
			 				<div class="summary">
			 					<h3>Summary</h3>
			 					<div class="summary-item"><span class="text">Subtotal</span><span class="price">$<?php echo $total_price;?></span></div>
			 					<!-- <div class="summary-item"><span class="text">Discount</span><span class="price">$0</span></div> -->
			 					<!-- <div class="summary-item"><span class="text">Shipping</span><span class="price">$0</span></div> -->
			 					<div class="summary-item"><span class="text">Total</span><span class="price">$<?php echo $total_price;?></span></div>
			 					<form action="payment.php" method="post">
			 						<input type="hidden" name="movies" value=<?php echo "\"".$_SESSION["cart"]."\"";?>>
			 					<button type="submit" class="btn btn-primary btn-lg btn-block">Checkout</button>
			 					<button type="button" class="btn btn-primary btn-lg btn-block" onclick="redirect1()">Remove all</button>
			 					<button type="button" class="btn btn-primary btn-lg btn-block" onclick="redirect2()">Continue Shopping</button>
				 			</div>
			 			</div>
		 			</div> 
		 		</div>
		</section>
	</main>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>