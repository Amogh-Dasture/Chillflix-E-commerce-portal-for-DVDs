-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: localhost    Database: ssl_project
-- ------------------------------------------------------
-- Server version	8.0.18

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ssl_project`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ssl_project` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `ssl_project`;

--
-- Table structure for table `movies`
--

DROP TABLE IF EXISTS `movies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movies` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `movie_name` varchar(100) NOT NULL,
  `img_directory` varchar(1000) NOT NULL,
  `recommended` int(11) DEFAULT NULL,
  `genre` varchar(20) DEFAULT NULL,
  `dealer_id` int(6) DEFAULT NULL,
  `descrip` varchar(8000) DEFAULT NULL,
  `cast` varchar(1000) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movies`
--

LOCK TABLES `movies` WRITE;
/*!40000 ALTER TABLE `movies` DISABLE KEYS */;
INSERT INTO `movies` VALUES (1,'Bad Boys 2','./movie_images/1.jpg',6,'action',3,'Two loose-cannon narcotics cops investigate the flow of Ecstasy into Florida from a Cuban drug cartel','Will Smith, Martin Lawrence, Gabrielle Union',30),(2,'Expendables 2','./movie_images/2.jpg',7,'action',3,'Mr. Church reunites the Expendables for what should be an easy paycheck, but when one of their men is murdered on the job, their quest for revenge puts them deep in enemy territory and up against an unexpected threat.','Sylvester Stallone, Liam Hemsworth, Randy Couture',40),(3,'Fast and Furious','./movie_images/3.jpg',NULL,'action',3,'Los Angeles police officer Brian OConner must decide where his loyalty really lies when he becomes enamored with the street racing world he has been sent undercover to destroy.','Vin Diesel, Paul walker',35),(4,'Kingsman','./movie_images/4.jpg',NULL,'action',3,'A spy organization recruits an unrefined, but promising street kid into the agencys ultra-competitive training program, just as a global threat emerges from a twisted tech genius.','Samuel L Jackson, Colin Firth',35),(5,'Matrix','./movie_images/5.jpg',NULL,'action',3,'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.','Samuel L Jackson, Colin Firth',35),(6,'MI:6','./movie_images/6.jpg',NULL,'action',3,'Ethan Hunt and his IMF team, along with some familiar allies, race against time after a mission gone wrong.','Tom Cruise, Henry Cavill',50),(7,'Shazam','./movie_images/7.jpg',NULL,'action',3,'We all have a superhero inside us, it just takes a bit of magic to bring it out. In Billy Batsons case, by shouting out one word - SHAZAM - this streetwise fourteen-year-old foster kid can turn into the grown-up superhero Shazam.','Zachary Levi, Mark Strong',30),(8,'Taken 3','./movie_images/8.jpg',NULL,'action',3,'Accused of a ruthless murder he never committed or witnessed, Bryan Mills goes on the run and brings out his particular set of skills to find the true killer and clear his name.',' Liam Neeson, Forest Whitaker, Maggie Grace ',30),(9,'Tomb Raider','./movie_images/9.jpg',NULL,'action',3,'Lara Croft, the fiercely independent daughter of a missing adventurer, must push herself beyond her limits when she discovers the island where her father disappeared.',' Alicia Vikander, Dominic West ',40),(10,'White House Down','./movie_images/10.jpg',NULL,'action',3,'While on a tour of the White House with his young daughter, a Capitol policeman springs into action to save his child and protect the president from a heavily armed group of paramilitary invaders.','Channing Tatum, Jamie Foxx, Maggie Gyllenhaal ',40),(11,'17 Again','./movie_images/11.jpg',NULL,'comedy',3,'Mike ODonnell is ungrateful for how his life turned out. He gets a chance to rewrite his life when he tried to save a janitor near a bridge and jumped after him into a time vortex.',' Zac Efron, Matthew Perry, Leslie Mann ',30),(12,'Hangover','./movie_images/12.jpg',8,'comedy',3,'Three buddies wake up from a bachelor party in Las Vegas, with no memory of the previous night and the bachelor missing. They make their way around the city in order to find their friend before his wedding.','  Zach Galifianakis, Bradley Cooper, Justin Bartha',30),(13,'Home Alone','./movie_images/13.jpg',NULL,'comedy',3,'An eight-year-old troublemaker must protect his house from a pair of burglars when he is accidentally left home alone by his family during Christmas vacation.','Macaulay Culkin, Joe Pesci, Daniel Stern',30),(14,'Horrible Bosses','./movie_images/14.jpg',NULL,'comedy',3,'Three friends conspire to murder their awful bosses when they realize they are standing in the way of their happiness.','Jason Bateman, Charlie Day, Jason Sudeikis',35),(15,'Madhouse','./movie_images/15.jpg',NULL,'comedy',3,'The luxurious villa of Mark and Jessie Bannister, a yuppie couple, is overrun by loads of uninvited guests who turn the house up side down.',' Richard Alexander, Kirstie Alley, John Larroquette',35),(16,'Night School','./movie_images/16.jpg',NULL,'comedy',3,'A group of high school dropouts are forced to attend night school in hope that they ll pass the GED exam to finish high school.','Kevin Hart, Tiffany Haddish, Rob Riggle ',35),(17,'Ace Ventura: Pet Detective','./movie_images/17.jpg',NULL,'comedy',3,'A goofy detective specializing in animals goes in search of the missing mascot of the Miami Dolphins.','Jim Carrey, Courteney Cox, Sean Young',35),(18,'Scary Movie','./movie_images/18.jpg',9,'comedy',3,'A year after disposing of the body of a man they accidentally killed, a group of dumb teenagers are stalked by a bumbling serial killer.','Anna Faris, Jon Abrahams, Marlon Wayans',35),(19,'Zohan','./movie_images/19.jpg',NULL,'comedy',3,'An Israeli Special Forces Soldier fakes his death so he can re-emerge in New York City as a hair stylist.','Adam Sandler, John Turturro, Emmanuelle Chriqui',35),(20,'Zombieland','./movie_images/20.jpg',NULL,'comedy',3,'A shy student trying to reach his family in Ohio, a gun-toting tough guy trying to find the last Twinkie, and a pair of sisters trying to get to an amusement park join forces to travel across a zombie-filled America.','Jesse Eisenberg, Emma Stone, Woody Harrelson',45),(21,'Good Boys','./movie_images/21.jpg',1,'comedy',3,'Three 6th grade boys ditch school and embark on an epic journey while carrying accidentally stolen drugs, being hunted by teenage girls, and trying to make their way home in time for a long-awaited party.','Jacob Tremblay, Keith L. Williams, Brady Noon',35),(22,'Angry Birds 2','./movie_images/22.jpg',2,'animated',3,'The flightless birds and scheming green pigs take their feud to the next level.','Jason Sudeikis, Josh Gad, Leslie Jones ',35),(23,'The Lion King','./movie_images/23.jpg',3,'animated',3,'After the murder of his father, a young lion prince flees his kingdom only to learn the true meaning of responsibility and bravery.',' Donald Glover, Beyoncé, Seth Rogen ',35),(24,'Hobbs and Shaw','./movie_images/24.jpg',4,'action',3,'Lawman Luke Hobbs and outcast Deckard Shaw form an unlikely alliance when a cyber-genetically enhanced villain threatens the future of humanity.','Dwayne Johnson, Jason Statham ',35),(25,'Spiderman: Far from Home','./movie_images/25.jpg',5,'action',3,'Mysterio tries to steal Edith from peter parker','Tom Holland, Samuel L Jackson, Jake Gyhenhall ',35),(26,'Aladdin','./movie_images/26.jpg',NULL,'animated',3,'Aladdin, the clever hero of Agrabah, continues his adventures with the help of his fiancee Princess Jasmine, his pet monkey Abu, Magic Carpet, Iago the greedy parrot, and of course his best friend the semi-cosmic Genie.','Scott Weinger, Linda Larkin, Dan Castellaneta',20),(27,'Epik','./movie_images/27.jpg',NULL,'drama',3,'EPik movie sd fg','Ben10, Kevin, Proxy',20),(28,'Euphoria','./movie_images/28.jpg',NULL,'drama',1,'Sisters in conflict travelling through Europe toward a mystery destination.','Alicia Vikander, Eva Green, Charles Dance',30),(29,'Free Fall','./movie_images/29.jpg',NULL,'drama',1,'After Ivan was diagnosed with ALS, his relationship with Lucas is challenged when he starts to lose control of his own body.','Chris McNally, Andrew Jenkins',35),(30,'Lifel','./movie_images/30.jpg',NULL,'drama',1,'A team of scientists aboard the International Space Station discover a rapidly evolving life form that caused extinction on Mars and now threatens all life on Earth.','Jake Gyllenhaal, Rebecca Ferguson, Ryan Reynolds ',30),(31,'Lion','./movie_images/31.jpg',NULL,'drama',3,'A five-year-old Indian boy gets lost on the streets of Calcutta, thousands of kilometers from home. He survives many challenges before being adopted by a couple in Australia. 25 years later, he sets out to find his lost family.','Dev Patel, Nicole Kidman, Rooney Mara',40),(32,'No String Attached','./movie_images/32.jpg',NULL,'romance',3,'A guy and girl try to keep their relationship strictly physical, but it\'s not long before they learn that they want something more.',' Natalie Portman, Ashton Kutcher, Kevin Kline ',25),(33,'The notebook','./movie_images/33.jpg',NULL,'romance',3,'A poor yet passionate young man falls in love with a rich young woman, giving her a sense of freedom, but they are soon separated because of their social differences.','Gena Rowlands, James Garner, Rachel McAdams',35),(34,'Love & Other Drugs','./movie_images/34.jpg',NULL,'romance',3,'A young woman suffering from Parkinson\'s befriends a drug rep working for Pfizer in 1990s Pittsburgh.','Jake Gyllenhaal, Anne Hathaway, Judy Greer ',25),(35,'Crazy, Stupid, Love','./movie_images/35.jpg',NULL,'romance',3,'A middle-aged husband\'s life changes dramatically when his wife asks him for a divorce. He seeks to rediscover his manhood with the help of a newfound friend, Jacob, learning to pick up girls at bars.',' Steve Carell, Ryan Gosling, Julianne Moore ',35),(36,'Pacific Rim: Uprising','./movie_images/36.jpg',NULL,'scifi',3,'Jake Pentecost, son of Stacker Pentecost, reunites with Mako Mori to lead a new generation of Jaeger pilots, including rival Lambert and 15-year-old hacker Amara, against a new Kaiju threat.',' John Boyega, Scott Eastwood, Cailee Spaeny',40),(37,'Ready Player One','./movie_images/37.jpg',NULL,'scifi',3,'When the creator of a virtual reality called the OASIS dies, he makes a posthumous challenge to all OASIS users to find his Easter Egg, which will give the finder his fortune and control of his world.','Tye Sheridan, Olivia Cooke, Ben Mendelsohn',30),(38,'Avatar','./movie_images/38.jpg',NULL,'scifi',3,'A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders and protecting the world he feels is his home.',' Sam Worthington, Zoe Saldana, Sigourney Weaver',50),(39,'Star Trek Beyond','./movie_images/39.jpg',NULL,'scifi',3,'The crew of the USS Enterprise explores the furthest reaches of uncharted space, where they encounter a new ruthless enemy, who puts them, and everything the Federation stands for, to the test.',' Chris Pine, Zachary Quinto, Karl Urban ',30),(40,'Toy Story 4','./movie_images/40.jpg',NULL,'animated',3,'When a new toy called \"Forky\" joins Woody and the gang, a road trip alongside old and new friends reveals how big the world can be for a toy.',' Tom Hanks, Tim Allen, Annie Potts',25),(41,'Cars','./movie_images/41.jpg',NULL,'animated',3,'A hot-shot race-car named Lightning McQueen gets waylaid in Radiator Springs, where he finds the true meaning of friendship and family.','Owen Wilson, Bonnie Hunt, Paul Newman ',15),(42,'Planes: Fire & Rescue','./movie_images/42.jpg',NULL,'animated',3,'When Dusty learns that his engine is damaged and he may never race again, he joins a forest fire and rescue unit to be trained as a firefighter, or else his air strip will be shut down.','Dane Cook, Ed Harris, Julie Bowen',30),(43,'abdc','./movie_images/43.jpg',NULL,'animated',3,'dummuy','dgdf',50);
/*!40000 ALTER TABLE `movies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `un` varchar(20) NOT NULL,
  `pw` varchar(100) NOT NULL,
  `purchased_movie_ids` varchar(8000) DEFAULT '',
  `sold_movie_ids` varchar(8000) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Shreyas','$2y$10$hF/aKMl5aywVZuR4Fa79n.51rGbcCIDN7FdFERdoHm1xRWdBE4OUa','','28'),(2,'amogh','$2y$10$99U1u2/0PyU8yDHkm.WY0.tMMW2yUfZ5rSgT6vGt09o1TAFkHzLRK','21',''),(3,'Ritwik','$2y$10$KIEqtKPrmNOQY.8FYSuu7OwPyGwM3b96hQscYd8/vZmQB2ZE9i3Yi','23,1,25,18,33,12,12,13','27,32,33,34,35,36,37,38,39,40,41,42,43'),(4,'Rupesh','$2y$10$POm0Ti9ZaCa/bAn8S4ap4uwhS8hC8dtC4BBaGlIp6oUiPchzZrQhq','22,23,22','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-13 21:52:51
